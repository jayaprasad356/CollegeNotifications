<?php
	//access key to access API
	$access_key = "90336";
	
	//google play url
	$gplay_url = "https://play.google.com/store/apps/details?id=com.city.ecommerce";
	
	// email configuration
	$email_subject = "Notification of changes to account information!";
	$change_message = "You have change your admin info such as email and or password.";
	$reset_message = "Your new password is ";
	
	//order notification configuration
	$reservation_subject = "New Order Notification!";
	$reservation_message = "There is new order, please check Admin Panel.";
	$order_subject = "Order Confirm Notification!";
	$order_message = "your order has been placed. we will reach to you very soon";
	
	$register_subject = "Thank You for Registering with City-Ecommerce";
	$register_message = "Thank You for Registering with City-Ecommerce. We Welcome you to best shopping experience for your family";
	$process_subject = "Confirmation mail for you City-Ecommerce order no ";
	$process_message = "Thank you for shopping at City-Ecommerce<br>
		The following items in your order will be shipped from our warehouse.<br>
		Once these items have been shipped, we will send you an email with the expected delivery date.<br>
		Order Details: <br>";
	$shipped_subject = " Your City-Ecommerce Order has been shipped from here";
	$shipped_message = "Thank you for your order on City-Ecommerce. Your Order No .";
						
	$delievered_subject = " Your City-Ecommerce order no.";
	$delievered_message = "Thank you for your order on City-Ecommerce. Your Order No .";
	//copyright
	$copyright = "";

?>